<div class="wrap">
<h1>Salut!</h1>
<p>Ceci est mon plugin</p>
</div>