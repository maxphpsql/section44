<?php


/* exemple 1 */

$i = 1;
while ($i <= 10) {
    /* afficher les opérations */
    echo $i++;  /* La valeur affichée est $i avant l'incrémentation
                   (post-incrémentation)  */
}

?>