for (let pas = 0; pas < 5; pas++) {
    // Ceci sera exécuté 5 fois
    // À chaque éxécution, la variable "pas" augmentera de 1
    // Lorsque'elle sera arrivée à 5, le boucle se terminera.
    // afficher les operations
    console.log('Faire ' + pas + ' pas vers l\'est' + '<br><br>');
  }