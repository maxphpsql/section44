﻿namespace Eta.Data
{
    public class Review
    {
        public string Description { get; set; }
        public int Id { get; set; }
        public int TrainingId { get; set; }
    }
}